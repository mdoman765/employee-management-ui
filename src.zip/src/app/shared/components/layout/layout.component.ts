import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { SidebarComponent } from '../sidebar/sidebar.component';
@Component({
  selector: 'app-layout', standalone: true,
  imports: [RouterOutlet, NavbarComponent, SidebarComponent],
  templateUrl: './layout.component.html', styleUrls: ['./layout.component.scss']
})
export class LayoutComponent { sidebarCollapsed = false; toggleSidebar(): void { this.sidebarCollapsed = !this.sidebarCollapsed; } }
