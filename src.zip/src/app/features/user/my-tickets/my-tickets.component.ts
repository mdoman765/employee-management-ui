import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TicketService } from '../../../core/services/ticket.service';
import { Ticket } from '../../../core/models/ticket.model';

@Component({
  selector: 'app-my-tickets', standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './my-tickets.component.html', styleUrls: ['./my-tickets.component.scss']
})
export class MyTicketsComponent implements OnInit {
  tickets: Ticket[] = []; loading = true; errorMsg = '';
  filterStatus = ''; expandedId: number | null = null;
  statuses = ['Open', 'InProgress', 'Closed'];

  constructor(private svc: TicketService) {}
  ngOnInit(): void {
    this.svc.getMine().subscribe({
      next: r => { this.tickets = r.data ?? []; this.loading = false; },
      error: () => { this.errorMsg = 'Failed to load tickets.'; this.loading = false; }
    });
  }

  get filtered(): Ticket[] { return this.filterStatus ? this.tickets.filter(t => t.status === this.filterStatus) : this.tickets; }
  toggle(id: number): void { this.expandedId = this.expandedId === id ? null : id; }
  priorityClass(p: string): string { return { High:'high', Medium:'medium', Low:'low' }[p] ?? ''; }
  statusClass(s: string): string   { return { Open:'open', InProgress:'inprogress', Closed:'closed' }[s] ?? ''; }
}
